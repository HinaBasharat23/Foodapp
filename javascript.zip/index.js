let a = parseInt(prompt("enter days of week"))
if(a==1){
    console.log("today is monday")
}
if (a==2){
    console.log("today is tuesday")
}
 if(a==3){
    console.log("today is wednesday")
}
 if(a==4){
    console.log("today is thursday")
}
 if(a==5){
    console.log("today is friday")
}
 if(a==6){
    console.log("today is saturday")
}
 if(a==7){
    console.log("today is sunday")
}
let m = parseInt(prompt("enter names of months"))
if(y==1){
    console.log("its january")
}
if(y==2){
    console.log("its febrary")
}
if(y==3){
    console.log("its march")
}
if(y==4){
    console.log("its april")
}
if(y==5){
    console.log("its may")
}
if(y==6){
    console.log("its june")
}
if(y==7){
    console.log("its july")
}
if(y==8){
    console.log("its august")
}
if(y==9){
    console.log("its september")
}
if(y==10){
    console.log("its october")
}
if(y==11){
    console.log("its november")
}
if(y==12){
    console.log("its december")
}