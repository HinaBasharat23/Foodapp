let b =[1,2,3,4,5,6,7,8,9]
for(let i of b){
    console.log(i)
}
for(let j=0; j<=b.length; j++ ){
    console.log(b[j]*2)
}
for(let j=0; j<=b.length; j++ ){
    console.log(b[j]+2)
}
for(let j=0; j<=b.length; j++ ){
    console.log(b[j]/2)
}
for(let j=0; j<=b.length; j++ ){
    console.log(b[j]-2)
}
let h=parseInt(prompt("enter any number 1-10"))
for(let k=0; k<=10; k++){
    let result=h*k;
    console.log(`${h} * ${k} = ${result}`)
}
functiontable(number)
for(let i=0; i<=10;i++){
    let result = i*number
    console.log(`${number} * ${i} = ${result}`)
}
table(2)
 